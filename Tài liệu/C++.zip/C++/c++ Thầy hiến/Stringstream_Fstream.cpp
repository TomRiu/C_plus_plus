"Created by Khanh Nguyen PTIT
Copyright © 2020 Khanh Nguyen. All rights reserved"

                        SỰ TƯƠNG ĐỒNG GIỮA STRINGSTREAM VÀ FSTREAM

CẦN NÓI RÕ HƠN ỨNG DỤNG STRINGSTREAM trong việc chuyển đổi giữa các kiểu dữ liệu

cụ thể tương đồng như nào: istream &is



(1) CÚ PHÁP ĐỌC DỮ LIỆU ĐẦU VÀO:

- FSTREAM: fstream f("địa chỉ đường dẫn", ios::in);
--> Nhập giá trị từ file văn bản nhập vào fstream
--> Trong trường hợp file để đọc dữ liệu và file chương trình cùng 1 thư mục thì chỉ cần truyền tên file
vào là đủ

- STRINGSTREAM: stringstream ss;    ss << biến có giá trị
--> Hiểu đơn giản thì cout << là lấy giá trị của biến có giá trị mang ra in --> Lấy giá trị của biến có giá
trị nhập vào ss(là stringstream)

Vd1: 
fstream f("Hello.txt", ios::in); --> Nhập giá trị từ file văn bản có tên "Hello.txt" nhập vào fstream

fstream f("c:\\users\\admin\\desktop\\Hello.txt",ios::in)

Vd2:
char s[100] = "Xin chao cac ban";

stringstream ss;    ss << s; -->Lấy giá trị của biến có giá trị nhập vào ss(là stringstream)


(2) CÁCH FILE NHẬP GIÁ TRỊ CHO TỪNG BIẾN/NHẬN DỮ LIỆU TỪ FILE (STRINGSTREAM CŨNG HOẠT ĐỘNG TƯƠNG TỰ)

- Để lưu kết quả giá trị từ file nhập vào biến thì nếu file chứa các chuỗi thì khởi tạo biến kiểu dữ liệu
chuỗi là char s[] hoặc string s để lưu. Còn đối với số thì có thể khởi tạo kiểu dữ liệu số hoặc chuỗi để lưu;

Vd: Để nhận giá trị từ file có nội dung là "Hi" thì phải khởi tạo kiểu dữ liệu chuỗi là char s[] hoặc string
để lưu. Còn nếu file có nội dung là "1 2 3" thì có thể khởi tạo kiểu dữ liệu số (int, float, double...) hoặc 
chuỗi (char s[] hoặc string s) để lưu


- Giả sử ta có 1 file "data.txt" có nội dung là "Xin chao cac ban"

fstream f("data.txt",ios::in); --> Đã chuyển dữ liệu từ file sang fstream

char s[100]; --> Hoặc khởi tạo string s để lưu, vì có thể chuyển đổi kiểu dữ liệu giữa các biến

cout << f.tellg() <<endl; --> in ra vị trí hiện tại của con trỏ file

while(f >> s){ --> Giống cin >> là nhập giá trị cho biến, nghĩa là nhập cho đến khi nào gặp khoảng trắng thì
kết thúc việc nhập cho biến
   
    cout << s << " " << f.tellg() << endl; --> in ra vị trí hiện tại của con trỏ file
}

--> Kết quả in màn hình: 
0
Xin 3
chao 8
tat 12
ca 15
cac 19
ban -1

--> Như vậy, ban đầu con trỏ file ở vị trí số 0, sau khi nhập từng giá trị từ file vào biến thì con trỏ file
trỏ ngay vị trí sau biến, và tại vị trí kết thúc file thì con trỏ trỏ đến vị trí -1

--> CÁCH HOẠT ĐỘNG TƯƠNG TỰ CHO STRINGSTREAM


(3) ỨNG DỤNG STRINGSTREAM ĐỂ TÁCH XÂU/ CHUYỂN CHUỖI SANG SỐ HOẶC NGƯỢC LẠI

Vd1: char a[] = "Xin chao cac ban";

stringstream ss;    ss << a;

char s[100]--> Hoặc khởi tạo string s để lưu, vì có thể chuyển đổi kiểu dữ liệu giữa các biến

while(ss >> s){
    cout << s << endl;
}

Vd2: char a[] = "123";

stringstream ss;    ss << a;

int b;      ff >> b;

Vd3: int a = 123;

stringstream ss;    ss << a;

char b[100];    ff >> b;

--> ỨNG DỤNG: Tương tự hàm itoal() ở bài "Chuỗi trong C": đếm số chẵn, số lẻ,...


(?) Vậy để tách xâu có ngăn cách bằng dấu phảy (',') hoặc khoảng trắng (' ') thì làm thế nào

- Tương tự hàm getline() đã giới thiệu trước đó. Chỉ cần thay cin bằng f là xong

- Chú ý: getline() bên C++ khác cin.getline() bên C là tham số truyền vào không phải char* s mà là string s

--> Vậy thì nếu char* s không làm được thì làm cách nào để tách?
Lại chuyển sang string bằng cách dùng stringstream để chuyển thôi

Vd1: char a[] = "Xin,chao,cac,ban";

stringstream ss;    ss << a;

string s;   ss >> s; --> Đã chuyển từ char* sang string

Vd2:
string a = "Xin,chao,cac,ban";

stringstream ss;    ss <<a;

string s;

while(ss >> s){
    cout << s <<endl;
}


(?) Khó hơn: Vậy thì muốn tách xâu được ngăn cách bằng nhiều lần kí tự ngăn các thì làm thế nào
--> Giới thiệu công cụ 