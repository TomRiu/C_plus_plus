#include <bits/stdc++.h>
using namespace std;
void docTep(float a[], int &n){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input16.dat", ios::in);
    f1>>n;
    for(int i = 0; i < n; i++)
        f1>>a[i];
    f1.close();
}
int kiemtrasapxep(float a[], int n){
    for(int i = 0; i < n-1; i++)
    {
        if(a[i] > a[i+1])
        return 0;
    }
    return 1;

}
void ghitep(float a[], int n)
{
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output16.dat", ios::out);
    f2<<kiemtrasapxep(a, n);
    f2.close();
}
int main(){
    float a[100];
    int n;
    docTep(a, n);
    ghitep(a, n);
}