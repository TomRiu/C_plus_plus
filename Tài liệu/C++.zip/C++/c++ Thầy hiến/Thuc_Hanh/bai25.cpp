#include <bits/stdc++.h>
using namespace std;

void doctep(string &a, int &n)
{
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input25.dat", ios::in);
    getline(f1, a);
    f1>>n;
    f1.close();
}
string trichtrai(string &a, int &n)
{
    string s;
    for(int i = a.length()-n-1; i < a.length(); i++)
        s = s+a[i];
    return s;
}
void ghitep(string a, int n)
{
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output25.dat", ios:: out);
    f2<<trichtrai(a, n);
    f2.close();
}
int main(){
    string a;
    int n, m;
    doctep(a, n);
    ghitep(a, n);
}