#include <bits/stdc++.h>
using namespace std;
void demso(float a[], int &n, float so[], int sl[], int &tongso){
    tongso = n;
    for(int i = 0; i < n; i++)
    {
        sl[i] = 0;
        for(int j = 0; j < n; j++)
        {
            if(a[i] == a[j])
            {
                if(j < i)
                    break;
                else 
                    sl[i]++;
            }
        }
    }
    for(int i = 0; i < n; i++)
    {
        if(sl[i] != 0)
            so[i] = a[i];
    }
    
}
void doctep(float a[], int &n)
{
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input22.dat", ios::in);
    f1>>n;
    for(int i = 0; i < n; i++)
        f1>>a[i];
    f1.close();
}
void ghitep(float so[], int sl[], int &tongso)
{
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output22.dat", ios::out);
    for(int i = 0; i < tongso; i++)
    {
        if(sl[i] != 0)
        f2<<so[i]<<" "<<sl[i]<<endl;
    }
    f2.close();
}
int main(){
    float a[100], so[100];
    int n, tongso, sl[100];
    doctep(a, n);
    demso(a, n, so, sl, tongso);
    ghitep(so, sl, tongso);
}