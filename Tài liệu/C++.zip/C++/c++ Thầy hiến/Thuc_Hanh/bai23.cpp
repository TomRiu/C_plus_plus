#include <bits/stdc++.h>
using namespace std;
string c[100], d[100];
int i, j;
void doctep(string &a, string &b)
{
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input23.dat", ios::in);
    i = 0, j = 0;
    getline(f1, a);
    getline(f1, b);
    f1.close();
}
int kt(string &a, string &b)
{
    int flat;
    stringstream aa, bb;
    aa << a, bb << b;
    string s;
    while (aa >> s)
        c[i++] = s; 
    while (bb >> s)
        d[j++] = s;
    for(int k = 0; k < j; k++)
    {
        flat = 0;
        for(int l = 0; l < i; l++)
        {
            if(c[l].compare(d[k]) == 0)
                flat = 1;
        }
        if(flat == 0)
        return 0;
    }
    return 1;
}
void ghitep(string &a, string &b)
{
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/outpat23.dat", ios::out);
    f2<<kt(a, b);
    f2.close();
}
int main(){
    string a, b;
    doctep(a, b);
    ghitep(a, b);
    
}