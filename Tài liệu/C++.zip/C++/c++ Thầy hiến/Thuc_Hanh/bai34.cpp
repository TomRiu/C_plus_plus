#include <bits/stdc++.h>
using namespace std;

void doctep(float a[], int &n){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input34.dat", ios::in);
    f1>>n;
    for(int i = 0; i < n; i++)
        f1>>a[i];
    f1.close();
}
void quicksort(float a[], int n, int l, int r){
    if(l <= r)
    {   
        int i = l, j = r;
        int mid = (l+r)/2;
        while(a[i] < a[mid])
            i++;
        while (a[j] > a[mid])
        {
            j--;
        }
        if(i <= j)
        {
            swap(a[i], a[j]);
            i++;
            j--;   
        }
        if(l < j)
        quicksort(a, n, l, j);
        if(r > i)
        quicksort(a, n, i, r);
    }
}
void ghitep(float a[], int n){
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output34.dat", ios::out);
    quicksort(a, n, 0, n-1);
    for (int i = 0; i < n; i++)
        f2<<a[i]<<" ";
    f2.close();
}
int main(){
    float a[100];
    int n;
    doctep(a, n);
    ghitep(a, n);
}