#include <bits/stdc++.h>
using namespace std;
string c[100], d[100], e[100];
int i, j, l;
void doctep(string &a, string &b)
{
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input32.dat", ios::in);
    i = 0, j = 0, l = 0;
    getline(f1, a);
    getline(f1, b);
    f1.close();
}
void xoa(string &a, string &b)
{
    int flat;
    stringstream aa, bb;
    aa << a, bb << b;
    string s;
    while (aa >> s)
        c[i++] = s;
    while (bb >> s)
        d[j++] = s;
    for(int x = 0; x < i; x++)
    {
        flat = 1;
        for(int y = 0; y < j; y++)
        {
            if(c[x].compare(d[y]) == 0)
                flat = 0;
        }
        if(flat)
        e[l++] = c[x];
    }
}
void ghitep(string &a, string &b)
{
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output32.dat", ios::out);
    xoa(a, b);
    for(int i = 0; i < l; i++)
        f2<<e[i]<<" ";
    f2.close();
}
int main(){
    string a, b;
    doctep(a, b);
    ghitep(a, b);
}