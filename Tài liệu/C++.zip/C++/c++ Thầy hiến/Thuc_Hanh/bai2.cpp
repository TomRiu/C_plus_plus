#include <bits/stdc++.h>
using namespace std;

void doctep(float &x, int &n)
{
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input2.dat", ios::in);
    f1>>x>>n;
    f1.close();
}
string doinhiphan(float x, int n)
{
    string a, b;
    long k = x, l = x;
    while (k)
    {
        a.push_back(k%2+'0');
        k/=2;
    }
    x = x-l;
    while(n--)
    {
        x*=2;
        l = x;
        if(x >= 1)
        x--;
        b.push_back(l+'0');
    }
    reverse(a.begin(), a.end());
    a.push_back('.');
    string s = a+b;
    return s;
}
void ghitep(float x, int n)
{
    string s =doinhiphan(x, n);
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output2.dat", ios::out);
    f2<<s;
    f2.close();
}
int main(){
    float x;
    int n;
    doctep(x, n);
    ghitep(x, n);
}