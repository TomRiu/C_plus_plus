#include <bits/stdc++.h>
using namespace std;
void docTep(float a[], int &n){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input4.dat", ios::in);
    f1>>n;
    for(int i = 0; i < n; i++)
        f1>>a[i];
    f1.close();
}
void insertionsort(float a[], int n){
    int i, j;
    float key;
    for (i = 1; i < n; i++)
    {
        key = a[i];
        j = i-1;
        while (j >= 0 && a[j] > key)
        {
            a[j+1] = a[j];
            j--;
        }
        a[j+1] = key;
    }  
} 
void ghitep(float a[], int n)
{
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output4.dat", ios::out);
    insertionsort(a, n);
    for(int i = 0; i < n; i++)
    f2<<a[i]<<" ";
    f2.close();
}
int main(){
    float a[100];
    int n;
    docTep(a, n);
    ghitep(a, n);
    
}