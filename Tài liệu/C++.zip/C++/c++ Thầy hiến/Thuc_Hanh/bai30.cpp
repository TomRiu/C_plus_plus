#include <bits/stdc++.h>
using namespace std;

void doctep(float a[], int &n){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input30.dat", ios::in);
    f1>>n;
    for(int i = 0; i < n; i++)
        f1>>a[i];
    f1.close();
}

void  solan1(float a[], int n, float a1[], int &m){
    int flat;
    m = 0;
    int count;
    for(int i = 0; i < n; i++)
    {
        count = 0;
        for(int j = 0; j < n; j++)
        {
            if(a[i] == a[j])
            {
                if(j < i)
                break;
                else 
                    count++;
            }
        }
        if(count == 2)
        a1[m++] = a[i];
    }
}  
void ghitep(float a[], int n, float a1[], int &m){
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output30.dat", ios::out);
    solan1(a, n, a1, m);
    for(int i = 0; i < m; i++)
        f2<<a1[i]<<" ";
    f2.close();
}
int main(){
    float a[100], a1[100];
    int n, m;
    doctep(a, n);
    ghitep(a, n, a1, m);
}