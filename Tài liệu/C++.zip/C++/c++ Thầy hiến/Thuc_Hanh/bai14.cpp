#include <bits/stdc++.h>
using namespace std;

void chuyenchuthuong(string &s)
{
    for (int i = 0; i < s.length(); i++)
    {
        if(s[i] >= 'a' && s[i] <= 'z')
            s[i]-=32;
    }
}

void doctep(string &s){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input14.dat", ios::in);
    getline(f1, s);
    f1.close();
}
void ghitep(string &s)
{
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output14.dat", ios::out);
    f2<<s;
    f2.close();
}
int main(){
    string s;
    doctep(s);
    chuyenchuthuong(s);
    ghitep(s);
}