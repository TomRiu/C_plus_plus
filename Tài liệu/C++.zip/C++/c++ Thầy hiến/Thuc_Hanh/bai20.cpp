#include <bits/stdc++.h>
using namespace std;

void doctep(string &s)
{
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input20.dat", ios::in);
    getline(f1, s);
    f1.close();
}
void demkytu1(string &s, string &kt, int sl[], int &tskt)
{
    tskt = 0;
    for(int i = 0; i < s.size()-1; i++)
    {
        if(s[i] != '\0' && s[i] != ' ')
        {
            sl[tskt] = 1;
            for(int j = i+1; j < s.size(); j++)
            {
                if(s[i] == s[j])
                {
                    s[j] = '\0';
                    sl[tskt]++;
                }
            }
            kt = kt + s[i];
            tskt++;
        }
    }
    sl[tskt++] = 1;
    if(s[s.size()-1] != '\0')
        kt = kt+s[s.size()-1];
}
void ghitep(string &kt, int sl[], int &tskt)
{
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output20.dat", ios::out);
    for(int i = 0; i < tskt; i++)
    {
        f2<<kt[i]<<" "<<sl[i]<<endl;
    }
    f2.close();
}
int main(){
    string s, kt;
    int sl[100], tskt;
    doctep(s);
    demkytu1(s, kt, sl, tskt);
    ghitep(kt, sl, tskt);
}