#include <bits/stdc++.h>
using namespace std;
void docTep(float a[], int &n){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input8.dat", ios::in);
    f1>>n;
    for(int i = 0; i < n; i++)
        f1>>a[i];
    f1.close();
}
float tongduong(float a[], int n){
    float sum = 0;
    for(int i = 0; i < n; i++)
    {
        if(a[i] > 0)
        sum +=a[i];
    }
    return sum;
}
void ghitep(float a[], int n)
{
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output8.dat", ios::out);
    int tong = tongduong(a, n);
    f2<<tong;
    f2.close();
}
int main(){
    float a[100];
    int n;
    docTep(a, n);
    ghitep(a, n);
}