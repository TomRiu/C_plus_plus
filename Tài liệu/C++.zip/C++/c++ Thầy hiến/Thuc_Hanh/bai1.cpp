#include <bits/stdc++.h>
using namespace std;
void docTep(long &n){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input.dat", ios::in);
    f1>>n;
    f1.close();
}
string doinhiphan(long n)
{
    string s;
    while (n)
    {
        s.push_back(n%2+'0');
        n/=2;
    }
    reverse(s.begin(), s.end());
    return s;
}
void ghitep(long n)
{
    string s = doinhiphan(n);
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output.dat", ios::out);
    f2<<s;
    f2.close();
}
int main(){
    long n;
    docTep(n);
    ghitep(n);
}