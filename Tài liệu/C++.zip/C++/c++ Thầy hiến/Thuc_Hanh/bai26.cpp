#include <bits/stdc++.h>
using namespace std;

void doctep(float a[], int &n, float &x){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input26.dat", ios::in);
    f1>>n;
    for(int i = 0; i < n; i++)
        f1>>a[i];
    f1>>x;
    f1.close();
}
void chenx(float a[], int &n,float x){
    int flat = 1;
    for(int i = 0; i < n; i++)
    {
        if(a[i] > x)
        {
            flat = 0;
            for(int j = n; j > i; j--)
                a[j] = a[j-1];
            a[i] = x;
            break;
        }
    }
    if(flat)
    a[n] = x;
    n++;
} 
void ghitep(float a[], int n)
{
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output26.dat", ios::out);
    for(int i = 0; i < n; i++)
        f2<<a[i]<<" ";
    f2.close();
}
int main(){
    float a[100], x;
    int n;
    doctep(a, n, x);
    chenx(a, n, x);
    ghitep(a, n);
}