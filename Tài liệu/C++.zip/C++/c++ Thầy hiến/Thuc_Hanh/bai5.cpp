#include <bits/stdc++.h>
using namespace std;
void docTep(float a[], int &n){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input5.dat", ios::in);
    f1>>n;
    for(int i = 0; i < n; i++)
        f1>>a[i];
    f1.close();
}
void bubblesort(float a[], int n){
    for(int i = 1; i < n; i++)
    {
        for(int j = n-1; j >= i; j--)
        {
            if(a[j] < a[j-1])
            swap(a[j], a[j-1]);
        }
    }
}
void ghitep(float a[], int n)
{
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output5.dat", ios::out);
    bubblesort(a, n);
    for(int i = 0; i < n; i++)
    f2<<a[i]<<" ";
    f2.close();
}
int main(){
    float a[100];
    int n;
    docTep(a, n);
    ghitep(a, n);
    
}