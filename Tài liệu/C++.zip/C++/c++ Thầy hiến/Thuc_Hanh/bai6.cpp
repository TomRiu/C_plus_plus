#include <bits/stdc++.h>
using namespace std;
void docTep(int &n){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input6.dat", ios::in);
    f1>>n;
    f1.close();
}
long giaithua(int n){
    if(n == 1)
    return 1;
    return n*giaithua(n-1);
}
void ghitep(int n)
{
    long a = giaithua(n);
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output6.dat", ios::out);
    f2<<a;
    f2.close();
}
int main(){
    int n;
    docTep(n);
    ghitep(n);
}