#include <bits/stdc++.h>
using namespace std;
void docTep(float a[], int &n){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input10.dat", ios::in);
    f1>>n;
    for(int i = 0; i < n; i++)
        f1>>a[i];
    f1.close();
}
float lonnhat(float a[], int n){
    float max = a[0];
    for(int i = 1; i < n; i++)
    {
        if(a[i] > max)
        max = a[i];
    }
    return max;
}
void ghitep(float a[], int n)
{
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output10.dat", ios::out);
    int max = lonnhat(a, n);
    f2<<max;
    f2.close();
}
int main(){
    float a[100];
    int n;
    docTep(a, n);
    ghitep(a, n);
}