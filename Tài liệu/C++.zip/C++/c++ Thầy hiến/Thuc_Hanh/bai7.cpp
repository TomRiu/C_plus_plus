#include <bits/stdc++.h>
using namespace std;
void docTep(float a[], int &n, float &x){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input7.dat", ios::in);
    f1>>n;
    for(int i = 0; i < n; i++)
        f1>>a[i];
    f1>>x;
    f1.close();
}
int demso(float a[], int n, float x){
    int count = 0;
    for (int i = 0; i < n; i++)
    {
        if(a[i] == x)
        count++;
    }
    return count;
} 
void ghitep(float a[], int n, float x){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output7.dat", ios::out);
    int dem = demso(a, n, x);
    f1<<dem;
    f1.close();
}
int main(){
    float a[100], x;
    int n;
    docTep(a, n, x);
    ghitep(a, n, x);
}