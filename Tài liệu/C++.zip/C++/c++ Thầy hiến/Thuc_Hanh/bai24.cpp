#include <bits/stdc++.h>
using namespace std;

void doctep(string &a, int &n, int &m)
{
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input24.dat", ios::in);
    getline(f1, a);
    f1>>n>>m;
    f1.close();
}
string trichtrai(string &a, int &n, int &m)
{
    string s;
    for(int i = m; i <= m+n; i++)
        s = s+a[i];
    return s;
}
void ghitep(string a, int n, int m)
{
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output24.dat", ios:: out);
    f2<<trichtrai(a, n, m);
    f2.close();
}
int main(){
    string a;
    int n, m;
    doctep(a, n, m);
    ghitep(a, n, m);
}