#include <bits/stdc++.h>
using namespace std;

int tongchuso(string &s)
{
    int count = 0;
    for (int i = 0; i < s.length(); i++)
    {
        if(s[i] >= '0' && s[i] <= '9')
            count++;
    }
    return count;
}

void doctep(string &s){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input17.dat", ios::in);
    getline(f1, s);
    f1.close();
}
void ghitep(string &s)
{
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output17.dat", ios::out);
    f2<<tongchuso(s);
    f2.close();
}
int main(){
    string s;
    doctep(s);
    ghitep(s);
}