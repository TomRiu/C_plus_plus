#include <bits/stdc++.h>
using namespace std;
float b[100];
void doctep(float a[], int &n){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input33.dat", ios::in);
    f1>>n;
    for(int i = 0; i < n; i++)
    {
        f1>>a[i];
        b[i] = a[i];
    }
    f1.close();
}
void timso(float a[], int &n, float &max1, int &vt1, float &max2, int &vt2){
    sort(b, b+n);
    max1 = b[n-1];
    int i = n-2;
    do
    {
        max2 = b[i--];
    } while (max1 < max2 && i >= 0);

    for(int i = 0; i < n; i++)
    {
        if(a[i] == max1)
        {
            vt1 = i;
            break;
        }
    }
    for(int i = 0; i < n; i++)
    {
        if(a[i] == max2)
        {
            vt2 = i;
            break;
        }
    }
}
void ghitep(float a[], int &n, float &max1, int &vt1, float &max2, int &vt2){
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output33.dat", ios::out);
    timso(a, n, max1, vt1, max2, vt2);
    f2<<max1<<" "<<vt1<<endl;
    f2<<max2<<" "<<vt2<<endl;
    f2.close();
}
int main(){
    float a[100], max1, max2;
    int n, vt1, vt2;
    doctep(a, n);
    
    ghitep(a, n, max1, vt1, max2, vt2);
}