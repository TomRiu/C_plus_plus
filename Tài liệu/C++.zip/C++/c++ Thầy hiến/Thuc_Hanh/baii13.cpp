#include <bits/stdc++.h>
using namespace std;

int tongchuhoa(string s)
{
    int count = 0;
    for (int i = 0; i < s.length(); i++)
    {
        if(s[i] >= 'a' && s[i] <= 'z')
            count++;
    }
    return count;
}

void doctep(string s){
    fstream f1("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/input13.dat", ios::in);
    int sum = 0;
    while (f1>>s)
    {
        sum+=tongchuhoa(s);
    }
    fstream f2("/media/bakachan/WIN 10/c_cousces/Thuc_Hanh/output13.dat", ios::out);
    f2<<sum;
    f2.close();
}

int main(){
    string s;
    doctep(s);
}